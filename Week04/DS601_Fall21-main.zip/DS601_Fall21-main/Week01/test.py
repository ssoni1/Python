
print('This script will print 0 through 9')

x = 10

for i in range(x):
    print(i)